﻿namespace Tableaux {

    using System.Collections.Generic;

    partial class Parser {
        Scanner _scanner;
        char _token;

        public Parser(Scanner scanner) {
            _scanner = scanner;
        }

        public Node Parse() {
            NextToken();
            var node = Expression();
            Expect(Scanner.End);
            return node;
        }

        private Node Expression() {
            var left = Implication();
            switch (_token) {
                case Scanner.Implies:
                case '&':
                case '|':
                    char oper = _token;
                    NextToken();
                    var right = Implication();
                    switch (oper) {
                        case '&': left = new Conjunction(left, right); break;
                        case '|': left = new Disjunction(left, right); break;
                    }
                    break;
            }
            return left;
        }

        private Node Implication() {
            var left = Primative();
            switch (_token) {
                case Scanner.Implies:
                    NextToken();
                    var right = Primative();
                    left = new Implication(left, right);
                    break;
            }
            return left;
        }

        private Node Primative() {
            Node node;
            switch (_token) {
                case Scanner.Identifier:
                    string name = _scanner.TokenText;
                    NextToken();
                    return new Variable(name);
                case '(':
                    NextToken();
                    node = Expression();
                    Expect(')');
                    return node;
                case '[':
                    NextToken();
                    node = Expression();
                    Expect(']');
                    return node;
                case '{':
                    NextToken();
                    node = Expression();
                    Expect('}');
                    return node;
                case '!':
                    NextToken();
                    node = Primative();
                    return new Negate(node);
                default:
                    Expect(Scanner.Identifier);
                    return null;
            }
        }

        private char NextToken() {
            _token = _scanner.NextToken();
            return _token;
        }

        private void Expect(char token) {
            if (_token != token) 
                Error("Unexpected {0}, expected {1}.", Scanner.TokenName(_token), Scanner.TokenName(token));
            NextToken();
        }

        private void Expect(string ident) {
            if (_token != Scanner.Identifier)
                Error("Unexpected {0}, expected {1}.", Scanner.TokenName(_token), ident);
            else {
                string tokenText = _scanner.TokenText;
                if (!string.Equals(tokenText, ident, System.StringComparison.InvariantCulture))
                    Error("Unexpected {0}, expected {1}.", tokenText, ident);
            }
            NextToken();
        }

        private string ExpectIdent() {
            if (_token != Scanner.Identifier)
                Expect(Scanner.Identifier);
            string ident = _scanner.TokenText;
            NextToken();
            return ident;
        }

        private void Error(string message) {
            throw new ParserError(message);
        }

        private void Error(string message, params object[] args) {
            Error(string.Format(message, args));
        }
    }
}