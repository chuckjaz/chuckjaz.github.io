﻿namespace Tableaux {

    // This is a proof mechanism using the Tableau Method as 
    // described in First-Order Logic by Raymond M. Smullyan.
    // ISBN-13: 978-0486683706

    using System;
    using System.Collections.Generic;

    // IsClosedTableau -----------------------------------------------------------------------

    abstract partial class Node {

        public abstract class TableauEntry {
            public abstract bool IsBranch { get; }
            public abstract bool IsClose { get; }

            public abstract SignedNode AsSignedNode { get; }
            public abstract Branch AsBranch { get; }
        }

        public class SignedNode: TableauEntry {
            public bool Sign;
            public Node Node;
            public SignedNode From;

            public override bool IsBranch { get { return false; } }
            public override bool IsClose { get { return false; } }

            public override SignedNode AsSignedNode { get { return this; } }
            public override Branch AsBranch { get { return null; } }

            public override string ToString() {
                return (Sign ? "T " : "F ") + Node.ToString();
            }
        }

        public class Branch : TableauEntry {
            public bool Left;

            public override bool IsBranch { get { return true; } }
            public override bool IsClose { get { return false; } }

            public override SignedNode AsSignedNode { get { return null; } }
            public override Branch AsBranch { get { return this; } }
        }

        public class Close : TableauEntry {
            public override bool IsBranch { get { return false; } }
            public override bool IsClose { get { return true; } }

            public override SignedNode AsSignedNode { get { return null; } }
            public override Branch AsBranch { get { return null; } }
        }

        public bool IsClosedTableau(ICollection<TableauEntry> tableau) {
            var bindings = new Dictionary<string, int>();
            var count = AssignBindings(bindings, 0);

            var values = new bool?[count];
            var alphaNodes = new Queue<SignedNode>();
            var betaNodes = new Queue<SignedNode>();

            alphaNodes.Enqueue(new SignedNode() { Sign = false, Node = this, From = null });
            tableau = tableau ?? new List<TableauEntry>();
            return IsClosedTableau(values, alphaNodes, betaNodes, tableau);
        }

        private static bool IsClosedTableau(bool?[] values, Queue<SignedNode> alphaNodes, Queue<SignedNode> betaNodes, 
            ICollection<TableauEntry> tableau) {
            while (alphaNodes.Count > 0) {
                var node = alphaNodes.Dequeue();
                tableau.Add(node);
                if (!node.Node.ProcessNode(node.Sign, values,
                    (s, n) => alphaNodes.Enqueue(new SignedNode() { Sign = s, Node = n, From = node }),
                    (s, n) => betaNodes.Enqueue(new SignedNode() { Sign = s, Node = n, From = node }))) {
                    tableau.Add(new Close());
                    return true;
                }
            }

            if (betaNodes.Count > 0) {
                var left = betaNodes.Dequeue();
                var right = betaNodes.Dequeue();
                var leftAlpha = new Queue<SignedNode>();
                leftAlpha.Enqueue(left);
                tableau.Add(new Branch() { Left = true });
                if (!IsClosedTableau(values.Clone() as bool?[], leftAlpha, Clone(betaNodes), tableau))
                    return false;

                var rightAlpha = new Queue<SignedNode>();
                rightAlpha.Enqueue(right);
                tableau.Add(new Branch() { Left = false });
                return IsClosedTableau(values, rightAlpha, Clone(betaNodes), tableau);
            }

            return false;
        }

        private static Queue<T> Clone<T>(Queue<T> queue) {
            var clone = new Queue<T>();
            foreach (var entry in queue)
                clone.Enqueue(entry);
            return clone;
        }

        internal abstract int AssignBindings(Dictionary<string, int> bindings, int index);

        internal protected delegate void Add(bool sign, Node node);
        internal abstract bool ProcessNode(bool value, bool?[] binding, Add addAlphaNode, Add addBetaNode);
    }

    // AssignBindings -----------------------------------------------------------------------

    partial class Variable {
        int _binding;

        internal override int AssignBindings(Dictionary<string, int> bindings, int index) {
            var result = index;
            int binding;
            if (!bindings.TryGetValue(_name, out binding)) {
                binding = index;
                bindings[_name] = index;
                result = index + 1;
            }
            _binding = binding;
            return result;
        }

    }

    partial class Negate {
        internal override int AssignBindings(Dictionary<string, int> bindings, int index) {
            return _subnode.AssignBindings(bindings, index);
        }
    }

    partial class BinaryNode {
        sealed internal override int AssignBindings(Dictionary<string, int> bindings, int index) {
            var result = _left.AssignBindings(bindings, index);
            result = _right.AssignBindings(bindings, result);
            return result;
        }
    }
    
    // ProcessNode -----------------------------------------------------------------------
    
    partial class Variable {
        internal override bool ProcessNode(bool value, bool?[] bindings, Add addAlphaNode, Add addBetaNode) {
            bool? binding = bindings[_binding];
            if (binding.HasValue)
                return binding.Value == value;
            else {
                bindings[_binding] = value;
                return true;
            }
        }
    }

    partial class Negate {
        // T !X     F !X
        // ----     ----
        // F X      T X
        //
        // If the negation is true the sub-expression must be false.
        // If the negation is false the sub-expression must be true.
        internal override bool ProcessNode(bool value, bool?[] binding, Add addAlphaNode, Add addBetaNode) {
            addAlphaNode(!value, _subnode);
            return true;
        }
    }

    partial class BinaryNode {
        internal protected void ProcessNodes(bool leftSign, bool rightSign, Add add) {
            add(leftSign, _left);
            add(rightSign, _right);
        }
    }

    partial class Conjunction {
        // T(X & Y)     F(X & Y)
        // --------     ---------
        //   T X        F X | F Y
        //   T Y
        //
        // If the conjunction is true the left and right must be also be true.
        // If the conjunction is false left or right can be false.
        internal override bool ProcessNode(bool value, bool?[] binding, Add addAlphaNode, Add addBetaNode) {
            if (value)
                ProcessNodes(true, true, addAlphaNode);
            else
                ProcessNodes(false, false, addBetaNode);
            return true;
        }
    }

    partial class Disjunction {
        // T(X | Y)     F(X | Y)
        // ---------    --------
        // T X | T Y      F X
        //                F Y
        //
        // If the disjunction is true either left or right is true.
        // If the disjunction is false both left and right must be false.
        internal override bool ProcessNode(bool value, bool?[] binding, Add addAlphaNode, Add addBetaNode) {
            if (value)
                ProcessNodes(true, true, addBetaNode);
            else
                ProcessNodes(false, false, addAlphaNode);
            return true;
        }
    }

    partial class Implication {
        // T(X -> Y)    F(X -> Y)
        // ---------    ---------
        // F X | T Y      T X
        //                F X
        //
        // If the implication is true either left is false or right is true.
        // If the implication is false both left must be true and right must be false.

        internal override bool ProcessNode(bool value, bool?[] binding, Add addAlphaNode, Add addBetaNode) {
            if (value)
                ProcessNodes(false, true, addBetaNode);
            else
                ProcessNodes(true, false, addAlphaNode);
            return true;
        }
    }

}