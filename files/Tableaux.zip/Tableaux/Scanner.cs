﻿namespace Tableaux {

    using System;
    using System.Globalization;

    internal class ParserError : Exception {
        public ParserError() { }
        public ParserError(string message) : base(message) { }
    }

    internal class Scanner {
		string _source;
		int _cur = 0;
		int _start = 0;
		char _token;

        public Scanner(string source) {
			this._source = source;
		}

        public string TokenText {
            get {
                return _source.Substring(_start, _cur - _start);
            }
        }

        private char GetChar(int index, int len) {
            return index < len ? _source[index] : '\0';
        }

		public char NextToken() {
			int p = _cur;
            int len = _source.Length;
			while (true) {
                _start = p;
                char c = GetChar(p++, len);
        		switch ( c ) {
					
                    case ' ': case '\t': case '\r': case '\n': continue;

                    case 'a': case 'b': case 'c': case 'd': case 'e':
                    case 'f': case 'g': case 'h': case 'i': case 'j':
                    case 'k': case 'l': case 'm': case 'n': case 'o': 
                    case 'p': case 'q': case 'r': case 's': case 't': 
                    case 'u': case 'v': case 'w': case 'x': case 'y': 
                    case 'z':
                    case 'A': case 'B': case 'C': case 'D': case 'E':
                    case 'F': case 'G': case 'H': case 'I': case 'J':
                    case 'K': case 'L': case 'M': case 'N': case 'O': 
                    case 'P': case 'Q': case 'R': case 'S': case 'T': 
                    case 'U': case 'V': case 'W': case 'X': case 'Y': 
                    case 'Z':
                    case '_':
                        while (true) {
                            c = GetChar(p++, len);
                            switch (c) {
                                case 'A': case 'B': case 'C': case 'D': case 'E':
                                case 'F': case 'G': case 'H': case 'I': case 'J':
                                case 'K': case 'L': case 'M': case 'N': case 'O': 
                                case 'P': case 'Q': case 'R': case 'S': case 'T': 
                                case 'U': case 'V': case 'W': case 'X': case 'Y': 
                                case 'Z':
                                case '_':
                                case '0': case '1': case '2': case '3': case '4':
                                case '5': case '6': case '7': case '8': case '9':
                                case 'a': case 'b': case 'c': case 'd': case 'e':
                                case 'f': case 'g': case 'h': case 'i': case 'j':
                                case 'k': case 'l': case 'm': case 'n': case 'o': 
                                case 'p': case 'q': case 'r': case 's': case 't': 
                                case 'u': case 'v': case 'w': case 'x': case 'y': 
                                case 'z':
                                    continue;
                                case ' ': case '\t': case '\0': case ';': case '(':
                                case ')': case ',': case '-':
                                case '\x1A':
                                case '\x2192':
                                    p--;
                                    break;
                                default:
                                    switch (char.GetUnicodeCategory(c)) {
                                        case UnicodeCategory.LetterNumber:
                                        case UnicodeCategory.LowercaseLetter:
                                        case UnicodeCategory.OtherLetter:
                                        case UnicodeCategory.TitlecaseLetter:
                                        case UnicodeCategory.UppercaseLetter:
                                        case UnicodeCategory.OtherNumber:
                                        case UnicodeCategory.ModifierLetter:
                                            continue;
                                        default:
                                            p--;
                                            break;
                                    }
                                    break;
                            }
                            break;
                        }
                        _token = Identifier;
                        break;
                                
					case '&': case '|': case '(': case ')': case '[': case ']': case '{': case '}': case '!': 
                    case ',': case ';':
                    case '\x1A':
                    case '\x2192':
                        _token = c;
						break;

                    case '-':
                        if (GetChar(p, len) == '>') {
                            _token = Implies;
                            p++;
                            break;
                        }
                        goto default;

					case '\0':
						_token = End;
						p--;
						break;

				    default:
                        switch (Char.GetUnicodeCategory(c)) {
                            case UnicodeCategory.LowercaseLetter:
                            case UnicodeCategory.OtherLetter:
                            case UnicodeCategory.TitlecaseLetter:
                            case UnicodeCategory.UppercaseLetter:
                                break;
                            default:
                                _cur = p;
                                throw new ParserError(string.Format("Invalid character '{0}'", _source[p-1]));
                        }
                        goto case 'A';
                }
				break;
			}
			_cur = p;
			return _token;
		}

        public char Token { get { return _token; } }
		public int Start { get { return _start; } }
		public int Current { get { return _cur; } }

		public const char End = '\x0';
		public const char Identifier = 'L';
        
        public const char Implies = '\x1A';

        public static string TokenName(char token) {
            switch (token) {
                case End: return "end of line";
                case Identifier: return "an identifier";
                case Implies: return "'->'";

                default: return "'" + token.ToString() + "'";
            }
        }
	}
}