﻿namespace Tableaux {

    using System.Text;

    abstract partial class Node {
        internal virtual bool IsSimple { get { return true; } }

        public override string ToString() {
            var builder = new StringBuilder();
            WriteTo(builder);
            return builder.ToString();
        }

        internal abstract void WriteTo(StringBuilder builder);
    }

    partial class Variable {
        public override string ToString() {
            return _name;
        }

        internal override void WriteTo(StringBuilder builder) {
            builder.Append(_name);
        }
    }

    partial class Negate {
        internal override void WriteTo(StringBuilder builder) {
            builder.Append('!');
            if (_subnode.IsSimple)
                _subnode.WriteTo(builder);
            else {
                builder.Append('(');
                _subnode.WriteTo(builder);
                builder.Append(')');
            }
        }
    }

    abstract partial class BinaryNode {

        internal override bool IsSimple { get { return false; } }

        internal abstract string Operator { get; }

        internal override void WriteTo(StringBuilder builder) {
            Add(builder, _left);
            builder.Append(Operator);
            Add(builder, _right);
        }

        new private void Add(StringBuilder builder, Node node) {
            if (node.IsSimple)
                node.WriteTo(builder);
            else {
                builder.Append('(');
                node.WriteTo(builder);
                builder.Append(')');
            }
        }
    }

    partial class Conjunction {
        internal override string Operator { get { return " & "; } }
    }

    partial class Disjunction {
        internal override string Operator { get { return " | "; } }
    }

    partial class Implication {
        internal override string Operator { get { return " \x2192 "; } }
    }
}