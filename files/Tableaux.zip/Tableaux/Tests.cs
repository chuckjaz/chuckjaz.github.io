﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Reflection;

namespace Tableaux {
    
    static class Tests {

        public static bool TestSimpleTautology() {
            return EnsureTautology("p | !p");
        }

        public static bool TestTransitiveImplies() {
            return EnsureTautology("(p->q & q->r) -> (p->r)");
        }

        public static bool TestDistributeOr() {
            return EnsureTautology("(p | (q & r)) -> ((p | q) & (p | r))");
        }

        public static bool TestSimpleVariable() {
            return EnsureNotTautology("simple_variable");
        }

        public static bool TestNonAscii() {
            return EnsureTautology("ÄƊἶὧᾔ | !ÄƊἶὧᾔ");
        }

        #region Test Utility Methods
        internal static bool RunAll() {
            bool result = true;

            var methods = typeof(Tests).GetMethods(BindingFlags.Static | BindingFlags.Public);
            var empty = new object[0];
            foreach (var method in methods)
                if (!(bool)method.Invoke(null, empty)) {
                    result = false;
                    Console.WriteLine("Failed {0}", method.Name);
                }

            if (result)
                Console.WriteLine("Success");

            return result;
        }

        private static bool EnsureTautology(string expression) {
            return TestTautology(expression, true);
        }

        private static bool EnsureNotTautology(string expression) {
            return TestTautology(expression, false);
        }

        private static bool TestTautology(string expression, bool expected) {
            var scanner = new Scanner(expression);
            var parser = new Parser(scanner);
            try {
                var node = parser.Parse();
                return node.IsClosedTableau(null) == expected;
            }
            catch {
                return false;
            }
        }

        private static bool EnsureParses(string expression) {
            var scanner = new Scanner(expression);
            var parser = new Parser(scanner);
            try {
                parser.Parse();
            }
            catch {
                return false;
            }
            return true;
        }

        private static bool EnsureDoesNotParse(string expression) {
            return !EnsureParses(expression);
        }
        #endregion

    }
}
