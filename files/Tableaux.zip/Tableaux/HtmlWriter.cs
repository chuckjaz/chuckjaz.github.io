﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Tableaux {
    static class HtmlWriter {
        public static string EmitTable(bool fullHtml, IEnumerable<Node.TableauEntry> tableau) {
            var builder = new StringBuilder();
            if (fullHtml)
                builder.Append(HtmlHeader);
            EmitTable(builder, tableau);
            if (fullHtml)
                builder.Append(HtmlFooter);
            return builder.ToString();
        }

        static string HtmlHeader =
@"<html><head><style type='text/css'>
.leftbranch {
	border-right-color: black; 
	border-right-style:solid; 
	border-right-width:thin; 
	padding-right: 10px
}
.rightbranch {
	padding-right:10px;
}
.nestedtable {
	text-align: center;
}
</style></head><body>";
        static string HtmlFooter =
@"</body></html>";

        static void EmitTable(StringBuilder builder, IEnumerable<Node.TableauEntry> tableau) {
            var orderTable = new Dictionary<Node.SignedNode, int>();
            var tableauEnum = tableau.GetEnumerator();
            tableauEnum.MoveNext();
            EmitTable(builder, null, tableauEnum, orderTable);
        }

        static void EmitTable(StringBuilder builder, string tableClass, IEnumerator<Node.TableauEntry> tableau,
            Dictionary<Node.SignedNode, int> orderTable) {
            if (tableClass != null) {
                builder.Append("<table class='");
                builder.Append(tableClass);
                builder.Append("'>");
            }
            else
                builder.Append("<table>");
            bool first = true;
            bool alphaClosed = true;
            do {
                Node.TableauEntry entry = tableau.Current;
                if (entry == null)
                    break;
                if (entry.IsBranch) {
                    Node.Branch branch = entry.AsBranch;
                    if (!branch.Left) {
                        break;
                    }
                    else {
                        if (!alphaClosed) {
                            builder.Append("</p></td></tr>");
                            alphaClosed = true;
                        }
                        tableau.MoveNext();
                        builder.Append("<tr><td valign='top' class='leftbranch'>");
                        EmitTable(builder, "nestedtable", tableau, orderTable);
                        tableau.MoveNext();
                        builder.Append("</td><td>");
                        EmitTable(builder, "nestedtable", tableau, orderTable);
                        builder.Append("</td valign='top' class='rightbranch'></tr>");
                    }
                }
                else if (entry.IsClose) {
                    builder.Append("X<br/>");
                    tableau.MoveNext();
                    break;
                }
                else {
                    if (first) {
                        builder.Append("<tr><td colspan='2'><p>");
                        alphaClosed = false;
                        first = false;
                    }

                    Node.SignedNode signedNode = tableau.Current.AsSignedNode;
                    if (orderTable.ContainsKey(signedNode)) {
                        orderTable.Remove(signedNode);
                        orderTable.Add(new Node.SignedNode(), -1);
                    }
                    orderTable[signedNode] = orderTable.Count + 1;
                    builder.Append('(');
                    builder.Append(orderTable.Count);
                    builder.Append(") ");
                    if (signedNode.Sign)
                        builder.Append('T');
                    else
                        builder.Append('F');
                    builder.Append(' ');
                    XmlEmit(builder, signedNode.Node.ToString());
                    if (signedNode.From != null) {
                        builder.Append(" (");
                        builder.Append(orderTable[signedNode.From]);
                        builder.Append(')');
                    }
                    builder.Append("<br/>");
                    tableau.MoveNext();
                }
            } while (true);
            if (!alphaClosed) {
                builder.Append("</p></td></tr>");
                alphaClosed = true;
            }
            builder.Append("</table>");
        }

        static void XmlEmit(StringBuilder builder, string value) {
            foreach (char ch in value) {
                switch (ch) {
                    case '&': builder.Append("&amp;"); break;
                    case '<': builder.Append("&lt;"); break;
                    case '>': builder.Append("&gt;"); break;
                    default: builder.Append(ch); break;
                }
            }
        }
    }
}
