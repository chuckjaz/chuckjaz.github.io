﻿namespace Tableaux {

    partial class Node { }

    // Some predicate variable
    partial class Variable : Node {
        string _name;

        public Variable(string name) {
            _name = name;
        }
    }

    // Expression form !X
    partial class Negate : Node {
        Node _subnode;

        public Negate(Node subnode) {
            _subnode = subnode;
        }
    }

    // Expression form X op Y
    partial class BinaryNode : Node {
        Node _left;
        Node _right;

        public BinaryNode(Node left, Node right) {
            _left = left;
            _right = right;
        }

        public Node Left { get { return _left; } }
        public Node Right { get { return _right; } }
    }

    // Expression form X & Y
    partial class Conjunction : BinaryNode {
        public Conjunction(Node left, Node right) : base(left, right) { }
    }

    // Expression form X | Y
    partial class Disjunction : BinaryNode {
        public Disjunction(Node left, Node right) : base(left, right) { }
    }

    // Expression form X -> Y
    partial class Implication : BinaryNode {
        public Implication(Node left, Node right) : base(left, right) { }
    }
}