﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Tableaux {

    class Program {
        static int Main(string[] args) {
            int i = 0;
            bool fullHtml = true;
            while (i < args.Length && (args[i][0] == '-' || args[i][0] == '/')) {
                switch (args[i].Substring(1)) {
                    case "p": case "partal": case "p+": case "partial+":
                        fullHtml = false;
                        break;
                    case "p-": case "partial-":
                        fullHtml = true;
                        break;
                    case "selftest":
                        if (Tests.RunAll())
                            return 0;
                        else
                            return 1;
                    default:
                        ReportError("Invalid option: {0}", args[i]);
                        return 1;
                }
                i++;
            }
            if (i >= args.Length) {
                ReportError("No logical expressiong given");
                return 1;
            }
            var expressionText = Combine(args, i);
            var scanner = new Scanner(expressionText);
            var parser = new Parser(scanner);
            try {
                var node = parser.Parse();
                var tableau = new List<Node.TableauEntry>();
                var isTautology = node.IsClosedTableau(tableau);
                var html = HtmlWriter.EmitTable(fullHtml, tableau);
                Console.WriteLine(html);
            }
            catch (ParserError e) {
                Console.WriteLine(expressionText);
                for (int j = 0; i < scanner.Start; j++)
                    Console.Write(' ');
                Console.WriteLine('^');
                ReportError(e.Message);
            }
            return 0;
        }

        static void ReportError(string message) {
            Console.WriteLine("Error: {0}", message);
        }

        static void ReportError(string message, params object[] args) {
            Console.WriteLine("Error: {0}", string.Format(message, args));
        }

        static string Combine(string[] args, int start) {
            return Combine(args, start, args.Length);
        }

        static string Combine(string[] args, int start, int end) {
            var builder = new StringBuilder();
            for (int i = start; i < end; i++) {
                builder.Append(args[i]);
                builder.Append(' ');
            }
            return builder.ToString();
        }
    }
}
